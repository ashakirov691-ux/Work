import logging
from aiogram import Router, F, Bot
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

from config import ADMIN_IDS
from emojis import E
from texts import TEXTS
from database import (
    upsert_user, get_user, update_user,
    get_operators, get_operator,
    create_service_request, get_request, update_request,
    is_phone_already_submitted,
    create_withdrawal, get_user_pending_withdrawal,
    is_service_open, is_user_banned
)
from keyboards import (
    main_menu_kb, profile_kb, cancel_kb, skip_photo_kb,
    services_kb, user_cancel_code_kb, admin_new_request_kb,
    admin_in_work_kb, admin_waiting_code_kb, reply_to_admin_kb
)
from states import ServiceState, WithdrawState, CodeState, ReplyState
from helpers import force_subscribe, is_subscribed, send_start_message, safe_edit, ordinal_ru

router = Router(name="user_router")

# ── Старт и главное меню ──
@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext, bot: Bot):
    await state.clear()
    uid = message.from_user.id
    if uid not in ADMIN_IDS and is_user_banned(uid):
        await message.answer(f"{E['cross']} <b>Ваш аккаунт заблокирован администратором.</b>", parse_mode="HTML")
        return
    upsert_user(
        uid,
        message.from_user.username or "",
        message.from_user.full_name or ""
    )
    if not await force_subscribe(message, bot):
        return
    await send_start_message(message, TEXTS["start_welcome"], main_menu_kb())

@router.callback_query(F.data == "check_sub")
async def check_sub_cb(callback: CallbackQuery, state: FSMContext, bot: Bot):
    if await is_subscribed(bot, callback.from_user.id):
        await state.clear()
        await callback.message.answer(TEXTS["sub_confirmed"], reply_markup=main_menu_kb(), parse_mode="HTML")
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.answer("Подписка подтверждена!")
    else:
        await callback.answer(TEXTS["sub_not_yet"], show_alert=True)

@router.callback_query(F.data == "back_main")
async def back_main(callback: CallbackQuery, state: FSMContext, bot: Bot):
    if not await force_subscribe(callback, bot):
        return
    await state.clear()
    await safe_edit(callback.message, TEXTS["main_menu"], main_menu_kb())

@router.callback_query(F.data == "cancel")
async def cancel_action(callback: CallbackQuery, state: FSMContext, bot: Bot):
    await state.clear()
    if not await force_subscribe(callback, bot):
        return
    await safe_edit(callback.message, TEXTS["action_cancelled"], main_menu_kb())

# ── Профиль ──
@router.callback_query(F.data == "profile")
async def show_profile(callback: CallbackQuery, bot: Bot):
    if not await force_subscribe(callback, bot):
        return
    u = get_user(callback.from_user.id)
    name = callback.from_user.full_name or "Пользователь"
    text = TEXTS["profile"].format(
        name,
        callback.from_user.id,
        u["completed"],
        u["in_work"],
        u["cancelled"],
        u["balance"],
        u["paid"]
    )
    await safe_edit(callback.message, text, profile_kb())

# ── Вывод средств ──
@router.callback_query(F.data == "withdraw")
async def withdraw_start(callback: CallbackQuery, state: FSMContext, bot: Bot):
    if not await force_subscribe(callback, bot):
        return
    u = get_user(callback.from_user.id)
    if u["balance"] <= 0:
        await callback.answer(TEXTS["withdraw_insufficient"], show_alert=True)
        return

    # Проверка: если уже есть активная заявка на вывод
    pending = get_user_pending_withdrawal(callback.from_user.id)
    if pending:
        await callback.answer(
            f"⚠️ У вас уже есть активная заявка на вывод #{pending['id']} на сумму {pending['amount']}$!\n"
            f"Дождитесь выплаты администратором.",
            show_alert=True
        )
        return

    await state.set_state(WithdrawState.waiting_amount)
    await safe_edit(
        callback.message,
        TEXTS["withdraw_prompt"].format(u["balance"]),
        cancel_kb()
    )

@router.message(WithdrawState.waiting_amount)
async def process_withdraw(message: Message, state: FSMContext, bot: Bot):
    u = get_user(message.from_user.id)
    try:
        amount = float(message.text.strip().replace(",", "."))
        if amount <= 0 or amount > u["balance"]:
            raise ValueError
    except (ValueError, AttributeError):
        await message.answer(TEXTS["withdraw_invalid_amount"], reply_markup=cancel_kb())
        return

    # Повторная проверка: есть ли уже активная заявка на вывод
    pending = get_user_pending_withdrawal(message.from_user.id)
    if pending:
        await state.clear()
        await message.answer(
            f"{E['warn']} <b>У вас уже есть активная заявка на вывод #{pending['id']}!</b>\n\n"
            f"Сумма: <b>{pending['amount']}$</b>\n"
            f"Статус: <b>Ожидает выплаты</b>\n\n"
            f"Вы не можете отправить новый запрос на вывод, пока предыдущий не будет обработан администратором.",
            reply_markup=main_menu_kb(),
            parse_mode="HTML"
        )
        return

    wid = create_withdrawal(
        message.from_user.id,
        message.from_user.username or message.from_user.full_name or str(message.from_user.id),
        amount
    )
    user_str = f"@{message.from_user.username}" if message.from_user.username else f"ID {message.from_user.id}"
    admin_text = TEXTS["withdraw_admin_notify"].format(
        wid,
        user_str,
        message.from_user.id,
        amount
    )
    for aid in ADMIN_IDS:
        try:
            await bot.send_message(aid, admin_text, parse_mode="HTML")
        except Exception as e:
            logging.warning(f"Ошибка уведомления админа {aid}: {e}")

    await state.clear()
    await message.answer(
        TEXTS["withdraw_created"].format(amount),
        reply_markup=main_menu_kb(),
        parse_mode="HTML"
    )

# ── Сдача сервиса ──
@router.callback_query(F.data == "submit_service")
async def submit_service(callback: CallbackQuery, bot: Bot):
    if not await force_subscribe(callback, bot):
        return
    if not is_service_open():
        await callback.answer(TEXTS["service_closed"], show_alert=True)
        return

    ops = get_operators(active_only=True)
    if not ops:
        await callback.answer("В данный момент нет доступных операторов.", show_alert=True)
        return
    text = TEXTS["choose_operator"]
    for op in ops:
        text += f"• {op['name']} — <b>{op['price']}$</b>\n"
    await safe_edit(callback.message, text, services_kb(ops))

@router.callback_query(F.data.startswith("service_"))
async def choose_service(callback: CallbackQuery, state: FSMContext, bot: Bot):
    if not await force_subscribe(callback, bot):
        return
    if not is_service_open():
        await callback.answer("Приём закрыт.", show_alert=True)
        return

    op_id = int(callback.data.replace("service_", ""))
    op = get_operator(op_id)
    if not op or not op["is_active"]:
        await callback.answer("Этот оператор сейчас недоступен для сдачи.", show_alert=True)
        return
    await state.set_state(ServiceState.waiting_phone)
    await state.update_data(op_id=op_id)
    await safe_edit(
        callback.message,
        TEXTS["enter_phone"].format(op["name"], op["price"]),
        cancel_kb()
    )

@router.message(ServiceState.waiting_phone)
async def process_phone(message: Message, state: FSMContext):
    phone = (message.text or "").strip()
    if not phone or len(phone) < 5:
        await message.answer(f"{E['cross']} Введите корректный номер телефона текстом:", reply_markup=cancel_kb())
        return

    # Проверка: не сдан ли данный номер (в очереди / в работе / ожидает код или уже выполнен)
    is_taken, reason = is_phone_already_submitted(phone)
    if is_taken:
        await message.answer(
            f"{E['cross']} <b>Номер не может быть принят:</b>\n\n"
            f"{reason}\n\n"
            f"Пожалуйста, введите другой номер или нажмите кнопку «Отмена»:",
            reply_markup=cancel_kb(),
            parse_mode="HTML"
        )
        return

    await state.update_data(phone=phone)
    await state.set_state(ServiceState.waiting_photo)
    await message.answer(
        TEXTS["attach_photo"],
        reply_markup=skip_photo_kb(),
        parse_mode="HTML"
    )

@router.message(ServiceState.waiting_photo, F.photo)
async def process_photo(message: Message, state: FSMContext, bot: Bot):
    await finish_service(message, state, message.photo[-1].file_id, bot)

@router.message(ServiceState.waiting_photo)
async def process_photo_wrong(message: Message, state: FSMContext):
    await message.answer(
        f"{E['cross']} Пожалуйста, отправьте <b>фотографию/скриншот</b> или нажмите кнопку <b>«Пропустить»</b>:",
        reply_markup=skip_photo_kb(),
        parse_mode="HTML"
    )

@router.callback_query(F.data == "skip_photo", ServiceState.waiting_photo)
async def skip_photo_cb(callback: CallbackQuery, state: FSMContext, bot: Bot):
    await finish_service(callback.message, state, None, bot, from_user=callback.from_user)

async def finish_service(message: Message, state: FSMContext, photo_file_id: str | None,
                         bot: Bot, from_user=None):
    data     = await state.get_data()
    op_id    = data.get("op_id")
    phone    = data.get("phone")
    op       = get_operator(op_id)
    user_obj = from_user or message.from_user
    uid      = user_obj.id

    if not op:
        await state.clear()
        await message.answer(f"{E['cross']} Ошибка: оператор не найден. Попробуйте снова.", reply_markup=main_menu_kb())
        return

    # Проверка номера перед сохранением
    is_taken, reason = is_phone_already_submitted(phone)
    if is_taken:
        await state.clear()
        await message.answer(
            f"{E['cross']} {reason}",
            reply_markup=main_menu_kb(),
            parse_mode="HTML"
        )
        return

    req_id = create_service_request(
        uid,
        user_obj.username or str(uid),
        op["id"],
        op["name"],
        op["price"],
        op["reward_amount"],
        phone,
        photo_file_id
    )
    u = get_user(uid)
    update_user(uid, in_work=u["in_work"] + 1)

    user_mention = f"@{user_obj.username}" if user_obj.username else "нет username"
    caption = TEXTS["new_request_admin"].format(
        req_id,
        user_mention,
        uid,
        op["name"],
        phone,
        op["price"],
        op["reward_amount"],
        (E["check"] if photo_file_id else "—")
    )

    first_admin_msg_id = None
    first_admin_id     = None
    for aid in ADMIN_IDS:
        try:
            if photo_file_id:
                sent = await bot.send_photo(
                    aid,
                    photo=photo_file_id,
                    caption=caption,
                    reply_markup=admin_new_request_kb(req_id),
                    parse_mode="HTML"
                )
            else:
                sent = await bot.send_message(
                    aid,
                    caption,
                    reply_markup=admin_new_request_kb(req_id),
                    parse_mode="HTML"
                )
            if first_admin_msg_id is None:
                first_admin_msg_id = sent.message_id
                first_admin_id     = aid
        except Exception as e:
            logging.warning(f"Ошибка отправки админу {aid}: {e}")

    update_request(req_id, admin_id=first_admin_id, admin_msg_id=first_admin_msg_id)
    await state.clear()
    await message.answer(
        TEXTS["request_created"].format(
            req_id,
            op["name"],
            phone,
            op["price"]
        ),
        reply_markup=main_menu_kb(),
        parse_mode="HTML"
    )

# ── Пользователь отправляет код ──
@router.message(CodeState.waiting_code)
async def user_sends_code(message: Message, state: FSMContext, bot: Bot):
    data   = await state.get_data()
    req_id = data.get("req_id")
    req    = get_request(req_id)

    if not req or req["status"] != "waiting_code":
        await state.clear()
        await message.answer(f"{E['cross']} Заявка не найдена или уже завершена.", reply_markup=main_menu_kb())
        return

    code       = message.text.strip() if message.text else "—"
    code_count = req.get("code_count", 0) + 1
    update_request(req_id, code_count=code_count, status="waiting_code")
    await state.clear()

    if req.get("admin_id"):
        try:
            await bot.send_message(
                req["admin_id"],
                TEXTS["code_received_admin"].format(
                    ordinal_ru(code_count),
                    req_id,
                    req["phone"],
                    code
                ),
                parse_mode="HTML",
                reply_markup=admin_waiting_code_kb(req_id)
            )
        except Exception as e:
            logging.warning(f"Не удалось отправить код админу {req['admin_id']}: {e}")

    await message.answer(
        TEXTS["code_sent_user"].format(
            ordinal_ru(code_count),
            code
        ),
        reply_markup=main_menu_kb(),
        parse_mode="HTML"
    )

# ── Отмена ввода кода ──
@router.callback_query(F.data.startswith("cancel_code_"))
async def user_cancel_code(callback: CallbackQuery, state: FSMContext, bot: Bot):
    await state.clear()
    req_id = int(callback.data.replace("cancel_code_", ""))
    req    = get_request(req_id)
    if req and req["status"] == "waiting_code":
        update_request(req_id, status="in_work")
    await safe_edit(callback.message, TEXTS["code_cancelled_user"], main_menu_kb())
    if req and req.get("admin_id"):
        try:
            u_name = f"@{req['username']}" if req.get("username") else f"ID {req['user_id']}"
            await bot.send_message(
                req["admin_id"],
                TEXTS["code_cancelled_admin"].format(
                    u_name,
                    req_id
                ),
                reply_markup=admin_in_work_kb(req_id),
                parse_mode="HTML"
            )
        except Exception:
            pass

# ── Ответ пользователя администратору ──
@router.callback_query(F.data.startswith("reply_admin_"))
async def user_reply_start(callback: CallbackQuery, state: FSMContext, bot: Bot):
    if not await force_subscribe(callback, bot):
        return
    admin_id = int(callback.data.replace("reply_admin_", ""))
    await state.set_state(ReplyState.waiting_text)
    await state.update_data(reply_admin_id=admin_id)
    await callback.message.answer(f"{E['pen']} Введите ваш ответ администратору:", reply_markup=cancel_kb())
    await callback.answer()

@router.message(ReplyState.waiting_text)
async def user_reply_send(message: Message, state: FSMContext, bot: Bot):
    data     = await state.get_data()
    admin_id = data.get("reply_admin_id")
    await state.clear()
    if not admin_id or not message.text:
        await message.answer(f"{E['cross']} Ошибка отправки. Попробуйте снова.", reply_markup=main_menu_kb())
        return
    try:
        u_name = f"@{message.from_user.username}" if message.from_user.username else "нет username"
        await bot.send_message(
            admin_id,
            TEXTS["reply_from_user"].format(
                u_name,
                message.from_user.id,
                message.text
            ),
            parse_mode="HTML",
            reply_markup=reply_to_admin_kb(message.from_user.id)
        )
        await message.answer(f"{E['check']} Ваш ответ успешно передан администратору.", reply_markup=main_menu_kb())
    except Exception as e:
        await message.answer(f"{E['cross']} Не удалось доставить сообщение: {e}", reply_markup=main_menu_kb())
