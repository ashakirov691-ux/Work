import asyncio
import logging
from datetime import datetime
from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.base import StorageKey

from config import ADMIN_IDS, MSK, WORK_START_HOUR, WORK_END_HOUR
from emojis import E
from texts import TEXTS
from database import (
    get_user, update_user, get_all_user_ids, get_all_users,
    ban_user, unban_user, is_user_banned,
    get_operators, get_operator, get_operator_by_code,
    create_operator, update_operator, delete_operator, swap_operator_sort,
    get_request, update_request, get_active_requests,
    get_pending_withdrawals, get_withdrawal, update_withdrawal,
    get_setting, set_setting, is_service_open, is_auto_mode
)
from keyboards import (
    admin_panel_kb, admin_new_request_kb, admin_in_work_kb,
    admin_waiting_code_kb, reply_to_admin_kb, reply_to_user_kb,
    admin_operators_kb, admin_op_detail_kb, admin_op_edit_fields_kb,
    admin_withdrawals_kb, admin_broadcast_preview_kb, cancel_kb, user_cancel_code_kb,
    admin_users_kb, admin_user_card_kb
)
from states import (
    AdminReplyState, BroadcastState, AdminState, AdminBanState,
    OpAddState, OpEditState, OpEmojiState, CodeState
)
from helpers import ordinal_ru, safe_edit

router = Router(name="admin_router")

def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS

def admin_status_text() -> str:
    open_state = is_service_open()
    auto       = is_auto_mode()
    status_str = f"{E['check']} <b>ОТКРЫТ</b>" if open_state else f"{E['cross']} <b>ЗАКРЫТ</b>"
    mode_str   = f"{E['clock']} <b>Авто (07:00–23:00 МСК)</b>" if auto else "<b>Ручной</b>"
    return TEXTS["admin_panel_status"].format(status_str, mode_str)

# ── Команда /admin ──
@router.message(Command("admin"))
async def cmd_admin(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer(TEXTS["admin_no_access"])
        return
    await message.answer(
        admin_status_text(),
        reply_markup=admin_panel_kb(is_service_open(), is_auto_mode()),
        parse_mode="HTML"
    )

# ── Команды /ban и /unban ──
@router.message(Command("ban"))
async def cmd_ban(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        await message.answer(TEXTS["admin_no_access"])
        return
    parts = (message.text or "").split(maxsplit=2)
    if len(parts) < 2:
        await message.answer(f"{E['cross']} <b>Формат:</b> <code>/ban {{user_id}} [причина]</code>", parse_mode="HTML")
        return
    try:
        target_id = int(parts[1])
    except ValueError:
        await message.answer(f"{E['cross']} ID пользователя должен быть числом.", parse_mode="HTML")
        return
    if target_id in ADMIN_IDS:
        await message.answer(f"{E['warn']} Нельзя заблокировать администратора.")
        return
    reason = parts[2] if len(parts) > 2 else "Нарушение правил сервиса"
    ban_user(target_id, reason)
    await message.answer(f"{E['check']} Пользователь <code>{target_id}</code> успешно <b>заблокирован</b>.", parse_mode="HTML")
    try:
        await bot.send_message(
            target_id,
            f"{E['cross']} <b>Ваш аккаунт заблокирован администратором.</b>\nПричина: {reason}",
            parse_mode="HTML"
        )
    except Exception:
        pass

@router.message(Command("unban"))
async def cmd_unban(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        await message.answer(TEXTS["admin_no_access"])
        return
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await message.answer(f"{E['cross']} <b>Формат:</b> <code>/unban {{user_id}}</code>", parse_mode="HTML")
        return
    try:
        target_id = int(parts[1])
    except ValueError:
        await message.answer(f"{E['cross']} ID пользователя должен быть числом.", parse_mode="HTML")
        return
    unban_user(target_id)
    await message.answer(f"{E['check']} Пользователь <code>{target_id}</code> <b>разблокирован</b>.", parse_mode="HTML")
    try:
        await bot.send_message(
            target_id,
            f"{E['check']} <b>Ваш аккаунт разблокирован администратором.</b>",
            parse_mode="HTML"
        )
    except Exception:
        pass

# ── Команда /emoji ──
@router.message(Command("emoji"))
async def cmd_emoji(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await message.answer(TEXTS["admin_no_access"])
        return
    await state.set_state(OpEmojiState.waiting_emoji)
    await state.update_data(op_id=None)
    await message.answer(
        f"{E['photo']} <b>Определение custom_emoji_id</b>\n\n"
        f"Отправьте премиум-эмодзи в ответ на это сообщение.\n"
        f"Бот определит его ID для вставки в кнопки или тексты.",
        reply_markup=cancel_kb(),
        parse_mode="HTML"
    )

# ── Команда /msg {id} {text} ──
@router.message(Command("msg"))
async def cmd_msg(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        await message.answer(TEXTS["admin_no_access"])
        return
    parts = (message.text or "").split(maxsplit=2)
    if len(parts) < 3:
        await message.answer(f"{E['cross']} <b>Формат:</b> <code>/msg {{id}} текст</code>", parse_mode="HTML")
        return
    try:
        target_id = int(parts[1])
    except ValueError:
        await message.answer(f"{E['cross']} ID пользователя должен быть числом.", parse_mode="HTML")
        return
    try:
        await bot.send_message(
            target_id,
            TEXTS["msg_from_admin"].format(parts[2]),
            parse_mode="HTML",
            reply_markup=reply_to_admin_kb(message.from_user.id)
        )
        await message.answer(f"{E['check']} Сообщение отправлено пользователю <code>{target_id}</code>.", parse_mode="HTML")
    except Exception as e:
        await message.answer(f"{E['cross']} Ошибка отправки: {e}")

# ── Ответ администратора пользователю через кнопку ──
@router.callback_query(F.data.startswith("msg_user_"))
async def admin_reply_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    target_id = int(callback.data.replace("msg_user_", ""))
    await state.set_state(AdminReplyState.waiting_text)
    await state.update_data(target_id=target_id)
    await callback.message.answer(
        f"{E['pen']} Введите ответ для пользователя <code>{target_id}</code>:",
        reply_markup=cancel_kb(),
        parse_mode="HTML"
    )
    await callback.answer()

@router.message(AdminReplyState.waiting_text)
async def admin_reply_send(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    data      = await state.get_data()
    target_id = data.get("target_id")
    await state.clear()
    if not target_id or not message.text:
        await message.answer(f"{E['cross']} Ошибка: пустое сообщение.")
        return
    try:
        await bot.send_message(
            target_id,
            TEXTS["msg_from_admin"].format(message.text),
            parse_mode="HTML",
            reply_markup=reply_to_admin_kb(message.from_user.id)
        )
        await message.answer(f"{E['check']} Сообщение доставлено пользователю <code>{target_id}</code>.", parse_mode="HTML")
    except Exception as e:
        await message.answer(f"{E['cross']} Не удалось доставить: {e}")

# ── Очередь заявок ──
@router.callback_query(F.data == "admin_queue")
async def admin_queue(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    queue = get_active_requests()
    if not queue:
        await callback.message.edit_text(
            TEXTS["admin_queue_empty"],
            reply_markup=admin_panel_kb(is_service_open(), is_auto_mode()),
            parse_mode="HTML"
        )
        return

    text = f"{E['list']} <b>Активные заявки в очереди:</b>\n\n"
    buttons = []
    for r in queue:
        status_icon = E["hourglass"] if r["status"] == "queue" else (E["pen"] if r["status"] == "waiting_code" else E["check"])
        u_name = f"@{r['username']}" if r.get("username") else f"ID {r['user_id']}"
        text += f"{status_icon} <b>#{r['id']}</b> | {r['service_name']} | <code>{r['phone']}</code> | {u_name}\n"
        buttons.append([InlineKeyboardButton(
            text=f"#{r['id']} — {r['service_name']} ({r['phone']})",
            callback_data=f"view_req_{r['id']}"
        )])
    buttons.append([InlineKeyboardButton(text="Назад в панель", callback_data="admin_back")])
    await callback.message.edit_text(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons), parse_mode="HTML")

@router.callback_query(F.data.startswith("view_req_"))
async def admin_view_request(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    req_id = int(callback.data.replace("view_req_", ""))
    req    = get_request(req_id)
    if not req:
        await callback.answer("Заявка не найдена.", show_alert=True)
        return

    smap = {
        "queue":        f"{E['hourglass']} В очереди",
        "in_work":      f"{E['check']} В работе",
        "waiting_code": f"{E['pen']} Ожидает код",
        "done":         f"{E['check']} Завершена",
        "cancelled":    f"{E['cross']} Отклонена"
    }
    u_name = f"@{req['username']}" if req.get("username") else "нет username"
    text = (
        f"{E['list']} <b>Детали заявки #{req_id}</b>\n\n"
        f"{E['user']} <b>Клиент:</b> {u_name} (<code>{req['user_id']}</code>)\n"
        f"{E['phone']} <b>Оператор:</b> {req['service_name']}\n"
        f"{E['call']} <b>Номер:</b> <code>{req['phone']}</code>\n"
        f"{E['money']} <b>Цена тарифа:</b> {req['price']}$\n"
        f"{E['gift']} <b>Начисление:</b> {req['reward_amount']}$\n"
        f"📊 <b>Статус:</b> {smap.get(req['status'], req['status'])}"
    )

    if req["status"] == "queue":
        kb = admin_new_request_kb(req_id)
    elif req["status"] == "in_work":
        kb = admin_in_work_kb(req_id)
    elif req["status"] == "waiting_code":
        kb = admin_waiting_code_kb(req_id)
    else:
        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="Назад к очереди", callback_data="admin_queue")
        ]])
    await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")

# ── Действия с заявкой: Взять в работу ──
@router.callback_query(F.data.startswith("take_"))
async def admin_take(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    req_id = int(callback.data.replace("take_", ""))
    req    = get_request(req_id)
    if not req:
        await callback.answer("Заявка не найдена.", show_alert=True)
        return
    if req["status"] != "queue":
        await callback.answer("Заявка уже обрабатывается.", show_alert=True)
        return

    update_request(req_id, status="in_work", admin_id=callback.from_user.id)
    old = callback.message.caption or callback.message.text or ""
    new = old + f"\n\n{E['hourglass']} <b>В РАБОТЕ</b> у администратора"
    try:
        if callback.message.photo:
            await callback.message.edit_caption(caption=new, reply_markup=admin_in_work_kb(req_id), parse_mode="HTML")
        else:
            await callback.message.edit_text(new, reply_markup=admin_in_work_kb(req_id), parse_mode="HTML")
    except Exception:
        pass

    try:
        await bot.send_message(
            req["user_id"],
            TEXTS["req_taken_user"].format(
                req_id,
                req["service_name"],
                req["phone"]
            ),
            parse_mode="HTML"
        )
    except Exception as e:
        logging.warning(f"Ошибка уведомления пользователя: {e}")
    await callback.answer("Заявка взята в работу")

# ── Запросить код у пользователя ──
@router.callback_query(F.data.startswith("req_code_"))
async def admin_request_code(callback: CallbackQuery, bot: Bot, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    req_id = int(callback.data.replace("req_code_", ""))
    req    = get_request(req_id)
    if not req or req["status"] not in ("in_work", "waiting_code"):
        await callback.answer("Нельзя запросить код для текущего статуса.", show_alert=True)
        return

    update_request(req_id, status="waiting_code")
    next_code_num = (req.get("code_count") or 0) + 1

    old = callback.message.caption or callback.message.text or ""
    label_line = f"\n\n{E['pen']} <b>Ожидаем код {ordinal_ru(next_code_num)} от пользователя...</b>"
    new = old + label_line
    try:
        if callback.message.photo:
            await callback.message.edit_caption(caption=new, reply_markup=admin_waiting_code_kb(req_id), parse_mode="HTML")
        else:
            await callback.message.edit_text(new, reply_markup=admin_waiting_code_kb(req_id), parse_mode="HTML")
    except Exception:
        pass

    try:
        await bot.send_message(
            req["user_id"],
            TEXTS["req_code_user"].format(
                ordinal_ru(next_code_num),
                req["phone"]
            ),
            parse_mode="HTML",
            reply_markup=user_cancel_code_kb(req_id)
        )
    except Exception as e:
        logging.warning(f"Не удалось отправить запрос кода клиенту: {e}")
        await callback.answer("Не удалось связаться с клиентом", show_alert=True)
        return

    user_key = StorageKey(bot_id=bot.id, chat_id=req["user_id"], user_id=req["user_id"])
    user_state = FSMContext(storage=state.storage, key=user_key)
    await user_state.set_state(CodeState.waiting_code)
    await user_state.update_data(req_id=req_id)

    await callback.answer(f"Запрошен код {ordinal_ru(next_code_num)}")

# ── Регион не подходит ──
@router.callback_query(F.data.startswith("wrong_region_"))
async def admin_wrong_region(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    req_id = int(callback.data.replace("wrong_region_", ""))
    req    = get_request(req_id)
    if not req:
        await callback.answer("Заявка не найдена.", show_alert=True)
        return

    update_request(req_id, status="cancelled")
    u = get_user(req["user_id"])
    update_user(req["user_id"], cancelled=u["cancelled"] + 1, in_work=max(0, u["in_work"] - 1))

    old = callback.message.caption or callback.message.text or ""
    new = old + f"\n\n{E['warn']} <b>РЕГИОН НЕ ПОДХОДИТ</b> (Закрыта)"
    try:
        if callback.message.photo:
            await callback.message.edit_caption(caption=new, parse_mode="HTML")
        else:
            await callback.message.edit_text(new, parse_mode="HTML")
    except Exception:
        pass

    try:
        await bot.send_message(
            req["user_id"],
            TEXTS["wrong_region_user"].format(
                req_id,
                req["phone"]
            ),
            parse_mode="HTML"
        )
    except Exception:
        pass
    await callback.answer("Пользователь уведомлён (регион не подошёл)")

# ── Завершить работу по заявке ──
@router.callback_query(F.data.startswith("done_"))
async def admin_done(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    req_id = int(callback.data.replace("done_", ""))
    req    = get_request(req_id)
    if not req or req["status"] in ("done", "cancelled"):
        await callback.answer("Заявка уже закрыта.", show_alert=True)
        return

    update_request(req_id, status="done")
    reward = req.get("reward_amount") or req.get("price", 0)
    u      = get_user(req["user_id"])
    new_bal = round(u["balance"] + reward, 2)
    update_user(
        req["user_id"],
        balance=new_bal,
        completed=u["completed"] + 1,
        in_work=max(0, u["in_work"] - 1)
    )

    old = callback.message.caption or callback.message.text or ""
    new = old + f"\n\n{E['check']} <b>УСПЕШНО ЗАВЕРШЕНО</b> — Начислено: +{reward}$"
    try:
        if callback.message.photo:
            await callback.message.edit_caption(caption=new, parse_mode="HTML")
        else:
            await callback.message.edit_text(new, parse_mode="HTML")
    except Exception:
        pass

    try:
        await bot.send_message(
            req["user_id"],
            TEXTS["req_done_user"].format(
                req_id,
                reward,
                new_bal
            ),
            parse_mode="HTML"
        )
    except Exception:
        pass
    await callback.answer(f"Заявка #{req_id} завершена, начислено {reward}$")

# ── Отклонить заявку ──
@router.callback_query(F.data.startswith("reject_"))
async def admin_reject(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    req_id = int(callback.data.replace("reject_", ""))
    req    = get_request(req_id)
    if not req or req["status"] in ("done", "cancelled"):
        await callback.answer("Заявка уже закрыта.", show_alert=True)
        return

    update_request(req_id, status="cancelled")
    u = get_user(req["user_id"])
    update_user(req["user_id"], cancelled=u["cancelled"] + 1, in_work=max(0, u["in_work"] - 1))

    old = callback.message.caption or callback.message.text or ""
    new = old + f"\n\n{E['cross']} <b>ОТКЛОНЕНО АДМИНИСТРАТОРОМ</b>"
    try:
        if callback.message.photo:
            await callback.message.edit_caption(caption=new, parse_mode="HTML")
        else:
            await callback.message.edit_text(new, parse_mode="HTML")
    except Exception:
        pass

    try:
        await bot.send_message(
            req["user_id"],
            TEXTS["req_rejected_user"].format(req_id),
            parse_mode="HTML"
        )
    except Exception:
        pass
    await callback.answer(f"Заявка #{req_id} отклонена")

# ── Блокировка клиента прямо из заявки ──
@router.callback_query(F.data.startswith("admin_ban_req_"))
async def admin_ban_from_req(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    req_id = int(callback.data.replace("admin_ban_req_", ""))
    req    = get_request(req_id)
    if not req:
        await callback.answer("Заявка не найдена.", show_alert=True)
        return
    client_id = req["user_id"]
    if client_id in ADMIN_IDS:
        await callback.answer("Нельзя заблокировать администратора!", show_alert=True)
        return

    ban_user(client_id, f"Заблокирован по заявке #{req_id}")
    if req["status"] in ("queue", "in_work", "waiting_code"):
        update_request(req_id, status="cancelled")
        u = get_user(client_id)
        update_user(client_id, cancelled=u["cancelled"] + 1, in_work=max(0, u["in_work"] - 1))

    await callback.answer(f"Пользователь {client_id} заблокирован!")
    old = callback.message.caption or callback.message.text or ""
    new = old + f"\n\n{E['cross']} <b>КЛИЕНТ ЗАБЛОКИРОВАН, ЗАЯВКА ЗАКРЫТА</b>"
    try:
        if callback.message.photo:
            await callback.message.edit_caption(caption=new, parse_mode="HTML")
        else:
            await callback.message.edit_text(new, parse_mode="HTML")
    except Exception:
        pass

    try:
        await bot.send_message(
            client_id,
            f"{E['cross']} <b>Ваш аккаунт заблокирован администратором.</b>",
            parse_mode="HTML"
        )
    except Exception:
        pass

# ── Управление операторами ──
@router.callback_query(F.data == "admin_operators")
async def admin_operators_list(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    ops  = get_operators(active_only=False)
    text = f"{E['phone']} <b>Управление тарифами и операторами:</b>\n\n"
    for op in ops:
        status = f"{E['check']} ON" if op["is_active"] else f"{E['cross']} OFF"
        text += f"[{status}] <b>{op['name']}</b> — {op['price']}$ (начисление: {op['reward_amount']}$)\n"
    if not ops:
        text += "Список операторов пуст. Нажмите кнопку ниже для добавления."
    await callback.message.edit_text(text, reply_markup=admin_operators_kb(ops), parse_mode="HTML")

@router.callback_query(F.data.startswith("admin_op_") &
                       ~F.data.startswith("admin_op_add") &
                       ~F.data.startswith("admin_op_toggle_") &
                       ~F.data.startswith("admin_op_edit_") &
                       ~F.data.startswith("admin_op_emoji_") &
                       ~F.data.startswith("admin_op_delete_") &
                       ~F.data.startswith("admin_op_up_") &
                       ~F.data.startswith("admin_op_down_"))
async def admin_op_detail(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    op_id = int(callback.data.replace("admin_op_", ""))
    op    = get_operator(op_id)
    if not op:
        await callback.answer("Оператор не найден.", show_alert=True)
        return
    ops    = get_operators(active_only=False)
    status = f"{E['check']} Активен" if op["is_active"] else f"{E['cross']} Отключен"
    text   = (
        f"{E['phone']} <b>Оператор: {op['name']}</b>\n\n"
        f"Код: <code>{op['code']}</code>\n"
        f"{E['money']} Цена для клиента: <b>{op['price']}$</b>\n"
        f"{E['gift']} Вознаграждение: <b>{op['reward_amount']}$</b>\n"
        f"Статус: {status}\n"
        f"Порядок сортировки: {op['sort_order']}\n"
        f"Кастомный эмодзи ID: <code>{op.get('custom_emoji_id') or 'по умолчанию'}</code>"
    )
    await callback.message.edit_text(text, reply_markup=admin_op_detail_kb(op, ops), parse_mode="HTML")

@router.callback_query(F.data.startswith("admin_op_toggle_"))
async def admin_op_toggle(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    op_id = int(callback.data.replace("admin_op_toggle_", ""))
    op    = get_operator(op_id)
    if not op:
        await callback.answer("Оператор не найден.", show_alert=True)
        return
    new_state = 0 if op["is_active"] else 1
    update_operator(op_id, is_active=new_state)
    op = get_operator(op_id)
    ops = get_operators(active_only=False)
    status_text = "включен" if new_state else "выключен"
    await callback.answer(f"Оператор {status_text}")
    text = (
        f"{E['phone']} <b>Оператор: {op['name']}</b>\n\n"
        f"Код: <code>{op['code']}</code>\n"
        f"{E['money']} Цена: <b>{op['price']}$</b>\n"
        f"{E['gift']} Вознаграждение: <b>{op['reward_amount']}$</b>\n"
        f"Статус: {E['check'] if new_state else E['cross']} ({status_text})\n"
        f"Порядок: {op['sort_order']}"
    )
    await callback.message.edit_text(text, reply_markup=admin_op_detail_kb(op, ops), parse_mode="HTML")
    change_type = "toggle_on" if new_state else "toggle_off"
    asyncio.create_task(_broadcast_operator_change(bot, op, change_type))

@router.callback_query(F.data.startswith("admin_op_up_"))
async def admin_op_up(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    op_id = int(callback.data.replace("admin_op_up_", ""))
    swap_operator_sort(op_id, "up")
    await callback.answer("Позиция поднята")
    op  = get_operator(op_id)
    ops = get_operators(active_only=False)
    await callback.message.edit_reply_markup(reply_markup=admin_op_detail_kb(op, ops))

@router.callback_query(F.data.startswith("admin_op_down_"))
async def admin_op_down(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    op_id = int(callback.data.replace("admin_op_down_", ""))
    swap_operator_sort(op_id, "down")
    await callback.answer("Позиция опущена")
    op  = get_operator(op_id)
    ops = get_operators(active_only=False)
    await callback.message.edit_reply_markup(reply_markup=admin_op_detail_kb(op, ops))

@router.callback_query(F.data.startswith("admin_op_delete_"))
async def admin_op_delete(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    op_id = int(callback.data.replace("admin_op_delete_", ""))
    op    = get_operator(op_id)
    if not op:
        await callback.answer("Оператор не найден.", show_alert=True)
        return
    delete_operator(op_id)
    await callback.answer(f"Оператор {op['name']} удалён")
    ops  = get_operators(active_only=False)
    text = f"{E['phone']} <b>Управление тарифами и операторами:</b>\n\n"
    for o in ops:
        icon = f"{E['check']} ON" if o["is_active"] else f"{E['cross']} OFF"
        text += f"[{icon}] <b>{o['name']}</b> — {o['price']}$\n"
    if not ops:
        text += "Операторов нет."
    await callback.message.edit_text(text, reply_markup=admin_operators_kb(ops), parse_mode="HTML")

# ── Редактирование оператора ──
@router.callback_query(F.data.startswith("admin_op_edit_") &
                       ~F.data.startswith("admin_op_edit_name_") &
                       ~F.data.startswith("admin_op_edit_price_") &
                       ~F.data.startswith("admin_op_edit_reward_"))
async def admin_op_edit_menu(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    op_id = int(callback.data.replace("admin_op_edit_", ""))
    op    = get_operator(op_id)
    if not op:
        await callback.answer("Оператор не найден.", show_alert=True)
        return
    await callback.message.edit_text(
        f"{E['pen']} <b>Редактирование {op['name']}</b>\n\nЧто вы хотите изменить?",
        reply_markup=admin_op_edit_fields_kb(op_id),
        parse_mode="HTML"
    )

@router.callback_query(F.data.startswith("admin_op_edit_name_"))
async def admin_op_edit_name(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    op_id = int(callback.data.replace("admin_op_edit_name_", ""))
    await state.set_state(OpEditState.waiting_value)
    await state.update_data(op_id=op_id, field="name")
    await callback.message.edit_text(f"{E['pen']} Введите новое название оператора:", reply_markup=cancel_kb())
    await callback.answer()

@router.callback_query(F.data.startswith("admin_op_edit_price_"))
async def admin_op_edit_price(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    op_id = int(callback.data.replace("admin_op_edit_price_", ""))
    await state.set_state(OpEditState.waiting_value)
    await state.update_data(op_id=op_id, field="price")
    await callback.message.edit_text(f"{E['money']} Введите новую цену ($):", reply_markup=cancel_kb())
    await callback.answer()

@router.callback_query(F.data.startswith("admin_op_edit_reward_"))
async def admin_op_edit_reward(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    op_id = int(callback.data.replace("admin_op_edit_reward_", ""))
    await state.set_state(OpEditState.waiting_value)
    await state.update_data(op_id=op_id, field="reward_amount")
    await callback.message.edit_text(f"{E['gift']} Введите размер вознаграждения ($):", reply_markup=cancel_kb())
    await callback.answer()

@router.message(OpEditState.waiting_value)
async def admin_op_edit_value(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    data  = await state.get_data()
    op_id = data["op_id"]
    field = data["field"]
    raw   = (message.text or "").strip().replace(",", ".")

    if field in ("price", "reward_amount"):
        try:
            value = float(raw)
            if value < 0: raise ValueError
        except ValueError:
            await message.answer(f"{E['cross']} Введите корректное положительное число:", reply_markup=cancel_kb())
            return
    else:
        value = raw
        if not value:
            await message.answer(f"{E['cross']} Название не может быть пустым:", reply_markup=cancel_kb())
            return

    old_op = get_operator(op_id)
    update_operator(op_id, **{field: value})
    await state.clear()
    op  = get_operator(op_id)
    ops = get_operators(active_only=False)
    await message.answer(
        f"{E['check']} <b>Параметры обновлены!</b>\n\n"
        f"{E['phone']} {op['name']} — {op['price']}$ | {E['gift']} {op['reward_amount']}$",
        reply_markup=admin_op_detail_kb(op, ops),
        parse_mode="HTML"
    )
    if field in ("price", "name"):
        asyncio.create_task(_broadcast_operator_change(bot, op, "edit", old_op=old_op))

# ── Настройка кастомного эмодзи для оператора ──
@router.callback_query(F.data.startswith("admin_op_emoji_"))
async def admin_op_emoji_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    op_id = int(callback.data.replace("admin_op_emoji_", ""))
    op    = get_operator(op_id)
    if not op:
        await callback.answer("Оператор не найден.", show_alert=True)
        return
    await state.set_state(OpEmojiState.waiting_emoji)
    await state.update_data(op_id=op_id)
    await callback.message.edit_text(
        f"{E['photo']} Отправьте <b>премиум-эмодзи</b> для оператора <b>{op['name']}</b>.\n\n"
        f"Чтобы сбросить эмодзи к стандартному — отправьте <code>clear</code>",
        reply_markup=cancel_kb(),
        parse_mode="HTML"
    )
    await callback.answer()

@router.message(OpEmojiState.waiting_emoji)
async def admin_op_emoji_receive(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    data  = await state.get_data()
    op_id = data.get("op_id")
    await state.clear()

    if message.text and message.text.strip().lower() == "clear":
        if op_id:
            update_operator(op_id, custom_emoji_id=None)
            op  = get_operator(op_id)
            ops = get_operators(active_only=False)
            await message.answer(f"{E['check']} Эмодзи сброшен.", reply_markup=admin_op_detail_kb(op, ops))
        return

    custom_emoji_id = None
    for entity in (message.entities or []):
        if entity.type == "custom_emoji":
            custom_emoji_id = entity.custom_emoji_id
            break

    if not custom_emoji_id:
        await message.answer(
            f"{E['cross']} В сообщении не найден premium custom_emoji.\n"
            f"Отправьте сообщение с <b>Telegram Premium эмодзи</b>.",
            parse_mode="HTML"
        )
        return

    if op_id is None:
        await message.answer(
            f"{E['check']} <b>ID обнаруженного эмодзи:</b>\n\n"
            f"ID для кнопок: <code>{custom_emoji_id}</code>\n"
            f"HTML тег для текстов: <code>&lt;tg-emoji emoji-id=\"{custom_emoji_id}\"&gt;😀&lt;/tg-emoji&gt;</code>",
            parse_mode="HTML"
        )
        return

    update_operator(op_id, custom_emoji_id=custom_emoji_id)
    op  = get_operator(op_id)
    ops = get_operators(active_only=False)
    await message.answer(
        f"{E['check']} Премиум-эмодзи для <b>{op['name']}</b> успешно привязан!\n\n"
        f"ID: <code>{custom_emoji_id}</code>",
        reply_markup=admin_op_detail_kb(op, ops),
        parse_mode="HTML"
    )

# ── Добавление оператора ──
@router.callback_query(F.data == "admin_op_add")
async def admin_op_add_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    await state.set_state(OpAddState.waiting_name)
    await callback.message.edit_text(
        f"{E['pen']} <b>Добавление нового оператора</b>\n\nВведите название (например, <i>Теле2</i>):",
        reply_markup=cancel_kb(),
        parse_mode="HTML"
    )
    await callback.answer()

@router.message(OpAddState.waiting_name)
async def admin_op_add_name(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id): return
    name = (message.text or "").strip()
    if not name:
        await message.answer(f"{E['cross']} Введите корректное название:", reply_markup=cancel_kb())
        return
    await state.update_data(name=name)
    await state.set_state(OpAddState.waiting_code)
    await message.answer(
        f"{E['check']} Название: <b>{name}</b>\n\n"
        f"Введите системный код латиницей (без пробелов, напр. <code>tele2</code>):",
        reply_markup=cancel_kb(),
        parse_mode="HTML"
    )

@router.message(OpAddState.waiting_code)
async def admin_op_add_code(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id): return
    code = (message.text or "").strip().lower().replace(" ", "_")
    if not code:
        await message.answer(f"{E['cross']} Введите код латиницей:", reply_markup=cancel_kb())
        return
    if get_operator_by_code(code):
        await message.answer(f"{E['cross']} Код <code>{code}</code> уже занят. Введите другой:", reply_markup=cancel_kb(), parse_mode="HTML")
        return
    await state.update_data(code=code)
    await state.set_state(OpAddState.waiting_price)
    await message.answer(f"{E['money']} Введите цену тарифа для пользователя ($):", reply_markup=cancel_kb(), parse_mode="HTML")

@router.message(OpAddState.waiting_price)
async def admin_op_add_price(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id): return
    try:
        price = float((message.text or "").strip().replace(",", "."))
        if price < 0: raise ValueError
    except ValueError:
        await message.answer(f"{E['cross']} Введите число (цену):", reply_markup=cancel_kb())
        return
    await state.update_data(price=price)
    await state.set_state(OpAddState.waiting_reward)
    await message.answer(f"{E['gift']} Введите сумму вознаграждения клиенту ($):", reply_markup=cancel_kb(), parse_mode="HTML")

@router.message(OpAddState.waiting_reward)
async def admin_op_add_reward(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id): return
    try:
        reward = float((message.text or "").strip().replace(",", "."))
        if reward < 0: raise ValueError
    except ValueError:
        await message.answer(f"{E['cross']} Введите число (вознаграждение):", reply_markup=cancel_kb())
        return
    data = await state.get_data()
    await state.clear()
    op_id = create_operator(data["code"], data["name"], data["price"], reward)
    op    = get_operator(op_id)
    ops   = get_operators(active_only=False)
    await message.answer(
        f"{E['check']} <b>Оператор успешно добавлен!</b>\n\n"
        f"{E['phone']} <b>{op['name']}</b> | {E['money']} {op['price']}$ | {E['gift']} {op['reward_amount']}$",
        reply_markup=admin_op_detail_kb(op, ops),
        parse_mode="HTML"
    )
    asyncio.create_task(_broadcast_operator_change(bot, op, "new"))

# ── Пополнение баланса пользователю ──
@router.callback_query(F.data == "admin_add_balance")
async def admin_add_balance_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    await state.set_state(AdminState.waiting_user_id)
    await callback.message.edit_text(
        f"{E['money']} <b>Пополнение баланса</b>\n\nВведите Telegram ID пользователя:",
        reply_markup=cancel_kb(),
        parse_mode="HTML"
    )

@router.message(AdminState.waiting_user_id)
async def admin_get_user_id(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id): return
    try:
        target_id = int(message.text.strip())
    except (ValueError, AttributeError):
        await message.answer(f"{E['cross']} ID должен быть числом. Повторите ввод:", reply_markup=cancel_kb())
        return
    await state.update_data(target_id=target_id)
    await state.set_state(AdminState.waiting_amount)
    await message.answer(
        f"{E['user']} Пользователь: <code>{target_id}</code>\n\n{E['money']} Введите сумму пополнения ($):",
        reply_markup=cancel_kb(),
        parse_mode="HTML"
    )

@router.message(AdminState.waiting_amount)
async def admin_set_amount(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id): return
    try:
        amount = float(message.text.strip().replace(",", "."))
        if amount <= 0: raise ValueError
    except (ValueError, AttributeError):
        await message.answer(f"{E['cross']} Введите корректную сумму:", reply_markup=cancel_kb())
        return
    data      = await state.get_data()
    target_id = data["target_id"]
    u         = get_user(target_id)
    new_bal   = round(u["balance"] + amount, 2)
    update_user(target_id, balance=new_bal)
    await state.clear()
    await message.answer(
        f"{E['check']} <b>Баланс успешно пополнен!</b>\n\n"
        f"{E['user']} ID: <code>{target_id}</code>\n"
        f"{E['money']} Начислено: <b>+{amount}$</b>\n"
        f"Текущий баланс: <b>{new_bal}$</b>",
        reply_markup=admin_panel_kb(is_service_open(), is_auto_mode()),
        parse_mode="HTML"
    )
    try:
        await bot.send_message(
            target_id,
            f"{E['gift']} <b>Ваш баланс пополнен!</b>\n\n"
            f"{E['money']} Начислено: <b>+{amount}$</b>\n"
            f"Текущий баланс: <b>{new_bal}$</b>",
            parse_mode="HTML"
        )
    except Exception:
        pass

# ── Заявки на вывод ──
@router.callback_query(F.data == "admin_withdrawals")
async def admin_show_withdrawals(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    pending = get_pending_withdrawals()
    if not pending:
        await callback.message.edit_text(
            TEXTS["admin_withdrawals_empty"],
            reply_markup=admin_panel_kb(is_service_open(), is_auto_mode()),
            parse_mode="HTML"
        )
        return
    text = f"{E['list']} <b>Активные заявки на вывод:</b>\n\n"
    for r in pending:
        u_name = f"@{r['username']}" if r.get("username") else f"ID {r['user_id']}"
        text += f"{E['money']} <b>#{r['id']}</b> | {u_name} | <b>{r['amount']}$</b>\n"
    await callback.message.edit_text(text, reply_markup=admin_withdrawals_kb(pending), parse_mode="HTML")

@router.callback_query(F.data.startswith("admin_pay_"))
async def admin_pay(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    wid = int(callback.data.replace("admin_pay_", ""))
    req = get_withdrawal(wid)
    if not req or req["status"] != "pending":
        await callback.answer("Заявка уже была обработана.", show_alert=True)
        return
    u = get_user(req["user_id"])
    if u["balance"] < req['amount']:
        await callback.answer("Недостаточно средств на балансе пользователя.", show_alert=True)
        return
    new_bal  = round(u["balance"] - req['amount'], 2)
    new_paid = round(u["paid"]    + req['amount'], 2)
    update_user(req["user_id"], balance=new_bal, paid=new_paid)
    update_withdrawal(wid, status="paid")
    u_name = f"@{req['username']}" if req.get("username") else f"ID {req['user_id']}"
    await callback.message.edit_text(
        f"{E['check']} Выплата <b>{req['amount']}$</b> для {u_name} подтверждена!",
        reply_markup=admin_panel_kb(is_service_open(), is_auto_mode()),
        parse_mode="HTML"
    )
    try:
        await bot.send_message(
            req["user_id"],
            TEXTS["withdraw_paid_user"].format(
                req['amount'],
                new_bal
            ),
            parse_mode="HTML"
        )
    except Exception:
        pass

@router.callback_query(F.data.startswith("admin_reject_pay_"))
async def admin_reject_pay(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    wid = int(callback.data.replace("admin_reject_pay_", ""))
    req = get_withdrawal(wid)
    if not req or req["status"] != "pending":
        await callback.answer("Заявка уже была обработана.", show_alert=True)
        return
    update_withdrawal(wid, status="cancelled")
    u_name = f"@{req['username']}" if req.get("username") else f"ID {req['user_id']}"
    await callback.message.edit_text(
        f"{E[cross]} Заявка на вывод #{wid} ({req['amount']}$) для {u_name} отклонена.",
        reply_markup=admin_panel_kb(is_service_open(), is_auto_mode()),
        parse_mode="HTML"
    )
    try:
        await bot.send_message(
            req["user_id"],
            f"{E[cross]} <b>Ваша заявка на вывод #{wid} на сумму {req['amount']}$ отклонена администратором.</b>",
            parse_mode="HTML"
        )
    except Exception:
        pass

# ── Список пользователей и управление ──
@router.callback_query(F.data == "admin_users")
async def admin_show_users(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    users = get_all_users(limit=100)
    if not users:
        await callback.message.edit_text(
            TEXTS["admin_users_empty"],
            reply_markup=admin_panel_kb(is_service_open(), is_auto_mode()),
            parse_mode="HTML"
        )
        return
    text = f"{E['user']} <b>Зарегистрированные пользователи (последние 100):</b>\n\n"
    for d in users:
        ban_badge = " [⛔ БАН]" if d.get("is_banned") else ""
        uname = f"@{d['username']}" if d.get("username") else "—"
        text += f"• 🆔 <code>{d['user_id']}</code> | {E['money']} {d['balance']}$ | {uname} ({d.get('full_name') or '—'}){ban_badge}\n"
    await callback.message.edit_text(text, reply_markup=admin_users_kb(users), parse_mode="HTML")

@router.callback_query(F.data == "admin_user_manage_by_id")
async def admin_user_manage_by_id_prompt(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    await state.set_state(AdminBanState.waiting_user_id)
    await callback.message.edit_text(
        f"{E['pen']} Введите Telegram ID пользователя для просмотра карточки и управления (бан/разбан/баланс):",
        reply_markup=cancel_kb(),
        parse_mode="HTML"
    )
    await callback.answer()

@router.message(AdminBanState.waiting_user_id)
async def admin_user_manage_by_id_receive(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id): return
    try:
        target_id = int(message.text.strip())
    except (ValueError, AttributeError):
        await message.answer(f"{E['cross']} ID должен быть числом. Повторите ввод:", reply_markup=cancel_kb())
        return
    await state.clear()
    u = get_user(target_id)
    status_str = f"{E['cross']} <b>ЗАБЛОКИРОВАН</b>" if u.get("is_banned") else f"{E['check']} <b>АКТИВЕН</b>"
    uname = f"@{u['username']}" if u.get("username") else "нет username"
    text = (
        f"{E['user']} <b>Карточка пользователя</b>\n\n"
        f"🆔 <b>ID:</b> <code>{target_id}</code>\n"
        f"👤 <b>Username:</b> {uname}\n"
        f"📝 <b>Имя:</b> {u.get('full_name') or '—'}\n"
        f"📊 <b>Статус:</b> {status_str}\n"
        f"{E['money']} <b>Баланс:</b> {u['balance']}$\n"
        f"{E['gift']} <b>Выплачено:</b> {u['paid']}$\n\n"
        f"📈 <b>Статистика заявок:</b>\n"
        f"• Выполнено: {u['completed']}\n"
        f"• В работе: {u['in_work']}\n"
        f"• Отклонено: {u['cancelled']}"
    )
    await message.answer(text, reply_markup=admin_user_card_kb(target_id, bool(u.get("is_banned"))), parse_mode="HTML")

@router.callback_query(F.data.startswith("admin_user_card_"))
async def admin_user_card_view(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    target_id = int(callback.data.replace("admin_user_card_", ""))
    u = get_user(target_id)
    status_str = f"{E['cross']} <b>ЗАБЛОКИРОВАН</b>" if u.get("is_banned") else f"{E['check']} <b>АКТИВЕН</b>"
    uname = f"@{u['username']}" if u.get("username") else "нет username"
    text = (
        f"{E['user']} <b>Карточка пользователя</b>\n\n"
        f"🆔 <b>ID:</b> <code>{target_id}</code>\n"
        f"👤 <b>Username:</b> {uname}\n"
        f"📝 <b>Имя:</b> {u.get('full_name') or '—'}\n"
        f"📊 <b>Статус:</b> {status_str}\n"
        f"{E['money']} <b>Баланс:</b> {u['balance']}$\n"
        f"{E['gift']} <b>Выплачено:</b> {u['paid']}$\n\n"
        f"📈 <b>Статистика заявок:</b>\n"
        f"• Выполнено: {u['completed']}\n"
        f"• В работе: {u['in_work']}\n"
        f"• Отклонено: {u['cancelled']}"
    )
    await callback.message.edit_text(text, reply_markup=admin_user_card_kb(target_id, bool(u.get("is_banned"))), parse_mode="HTML")

@router.callback_query(F.data.startswith("admin_ban_") & ~F.data.startswith("admin_ban_req_"))
async def admin_ban_callback(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    target_id = int(callback.data.replace("admin_ban_", ""))
    if target_id in ADMIN_IDS:
        await callback.answer("Нельзя заблокировать администратора!", show_alert=True)
        return
    ban_user(target_id)
    await callback.answer("Пользователь заблокирован!")
    try:
        await bot.send_message(target_id, f"{E['cross']} <b>Ваш аккаунт заблокирован администратором.</b>", parse_mode="HTML")
    except Exception:
        pass
    await callback.message.edit_reply_markup(reply_markup=admin_user_card_kb(target_id, True))

@router.callback_query(F.data.startswith("admin_unban_"))
async def admin_unban_callback(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    target_id = int(callback.data.replace("admin_unban_", ""))
    unban_user(target_id)
    await callback.answer("Пользователь разблокирован!")
    try:
        await bot.send_message(target_id, f"{E['check']} <b>Ваш аккаунт разблокирован администратором.</b>", parse_mode="HTML")
    except Exception:
        pass
    await callback.message.edit_reply_markup(reply_markup=admin_user_card_kb(target_id, False))

@router.callback_query(F.data.startswith("admin_add_balance_"))
async def admin_add_balance_shortcut(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    target_id = int(callback.data.replace("admin_add_balance_", ""))
    await state.set_state(AdminState.waiting_amount)
    await state.update_data(target_id=target_id)
    await callback.message.edit_text(
        f"{E['user']} Пользователь: <code>{target_id}</code>\n\n{E['money']} Введите сумму пополнения ($):",
        reply_markup=cancel_kb(),
        parse_mode="HTML"
    )
    await callback.answer()

# ── Рассылка ──
@router.callback_query(F.data == "admin_broadcast")
async def admin_broadcast_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    await state.set_state(BroadcastState.waiting_text)
    await callback.message.edit_text(
        f"{E['send']} <b>Создание массовой рассылки</b>\n\n"
        f"Отправьте текст сообщения для всех пользователей бота (поддерживается HTML-разметка):",
        reply_markup=cancel_kb(),
        parse_mode="HTML"
    )

@router.message(BroadcastState.waiting_text)
async def admin_broadcast_preview(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id): return
    if not message.text:
        await message.answer(f"{E['cross']} Рассылка поддерживает только текстовые сообщения.", reply_markup=cancel_kb())
        return
    await state.update_data(broadcast_text=message.text)
    await state.set_state(BroadcastState.confirm_text)
    user_count = len(get_all_user_ids())
    await message.answer(
        f"{E['list']} <b>Предпросмотр сообщения для рассылки:</b>\n\n"
        f"━━━━━━━━━━━━━━━━━━━\n{message.text}\n━━━━━━━━━━━━━━━━━━━\n\n"
        f"{E['user']} Получателей в базе: <b>{user_count}</b>",
        reply_markup=admin_broadcast_preview_kb(user_count),
        parse_mode="HTML"
    )

@router.callback_query(F.data == "broadcast_edit")
async def broadcast_edit(callback: CallbackQuery, state: FSMContext):
    await state.set_state(BroadcastState.waiting_text)
    await callback.message.edit_text(f"{E['pen']} Введите новый текст рассылки:", reply_markup=cancel_kb())

@router.callback_query(F.data == "broadcast_confirm")
async def broadcast_confirm(callback: CallbackQuery, state: FSMContext, bot: Bot):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    data = await state.get_data()
    text = data.get("broadcast_text")
    await state.clear()
    if not text:
        await callback.answer("Текст рассылки отсутствует.", show_alert=True)
        return

    user_ids   = get_all_user_ids()
    status_msg = await callback.message.edit_text(f"{E['hourglass']} Выполняется отправка для {len(user_ids)} пользователей...")
    sent, failed = 0, 0
    for uid in user_ids:
        try:
            await bot.send_message(uid, text, parse_mode="HTML")
            sent += 1
        except Exception:
            failed += 1
        await asyncio.sleep(0.04)

    await status_msg.edit_text(
        f"{E['check']} <b>Рассылка успешно завершена!</b>\n\n"
        f"{E['send']} Доставлено: <b>{sent}</b>\n"
        f"{E['cross']} Ошибок доставки: <b>{failed}</b>",
        parse_mode="HTML",
        reply_markup=admin_panel_kb(is_service_open(), is_auto_mode())
    )

# ── Переключение режимов работы сервиса ──
@router.callback_query(F.data == "admin_back")
async def admin_back(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    await callback.message.edit_text(
        admin_status_text(),
        reply_markup=admin_panel_kb(is_service_open(), is_auto_mode()),
        parse_mode="HTML"
    )

@router.callback_query(F.data == "toggle_service_off")
async def admin_toggle_off(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    set_setting("service_open", "0")
    set_setting("auto_mode", "0")
    await callback.message.edit_text(
        admin_status_text(),
        reply_markup=admin_panel_kb(is_service_open(), is_auto_mode()),
        parse_mode="HTML"
    )
    await callback.answer("Приём сервисов остановлен")

@router.callback_query(F.data == "toggle_service_on")
async def admin_toggle_on(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    set_setting("service_open", "1")
    set_setting("auto_mode", "0")
    await callback.message.edit_text(
        admin_status_text(),
        reply_markup=admin_panel_kb(is_service_open(), is_auto_mode()),
        parse_mode="HTML"
    )
    await callback.answer("Приём сервисов запущен")

@router.callback_query(F.data == "auto_on")
async def admin_auto_on(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    set_setting("auto_mode", "1")
    now = datetime.now(MSK)
    set_setting("service_open", "1" if WORK_START_HOUR <= now.hour < WORK_END_HOUR else "0")
    await callback.message.edit_text(
        admin_status_text(),
        reply_markup=admin_panel_kb(is_service_open(), is_auto_mode()),
        parse_mode="HTML"
    )
    await callback.answer("Авто-режим работы включен")

@router.callback_query(F.data == "auto_off")
async def admin_auto_off(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer(TEXTS["admin_no_access"], show_alert=True)
        return
    set_setting("auto_mode", "0")
    await callback.message.edit_text(
        admin_status_text(),
        reply_markup=admin_panel_kb(is_service_open(), is_auto_mode()),
        parse_mode="HTML"
    )
    await callback.answer("Авто-режим выключен")

# ── Автооповещения пользователям об операторах ──
async def _broadcast_operator_change(bot: Bot, op: dict, change_type: str, old_op: dict = None):
    """Рассылает всем пользователям уведомление об изменении тарифов или статуса оператора."""
    if change_type == "new":
        text = (
            f"{E['gift']} <b>Добавлен новый оператор!</b>\n\n"
            f"{E['phone']} <b>{op['name']}</b>\n"
            f"{E['money']} Тариф: <b>{op['price']}$</b>\n"
            f"{E['gift']} Вознаграждение: <b>{op['reward_amount']}$</b>\n\n"
            f"Уже доступен для сдачи в меню бота!"
        )
    elif change_type == "toggle_off":
        text = (
            f"{E['warn']} <b>Внимание: временная приостановка</b>\n\n"
            f"Приём по оператору <b>{op['name']}</b> временно приостановлен."
        )
    elif change_type == "toggle_on":
        text = (
            f"{E['check']} <b>Приём возобновлён!</b>\n\n"
            f"Оператор <b>{op['name']}</b> снова доступен для сдачи ({op['price']}$)."
        )
    elif change_type == "edit" and old_op:
        changes = []
        if old_op["name"] != op["name"]:
            changes.append(f"Название: {old_op['name']} → {op['name']}")
        if old_op["price"] != op["price"]:
            changes.append(f"Цена: {old_op['price']}$ → {op['price']}$")
        if not changes:
            return
        text = (
            f"{E['pen']} <b>Обновление условий тарифа</b>\n\n"
            f"<b>{op['name']}</b>:\n" +
            "\n".join(f"• {c}" for c in changes)
        )
    else:
        return

    user_ids = get_all_user_ids()
    for uid in user_ids:
        try:
            await bot.send_message(uid, text, parse_mode="HTML")
        except Exception:
            pass
        await asyncio.sleep(0.04)
